from flask import Flask, render_template, request, jsonify
import openai

app = Flask(__name__)

# 在这里填入你的OpenAI API密钥
openai.api_base = "https://api.chatanywhere.com.cn/v1"
openai.api_key = 'sk-GheB7h42VTcUewSgHAK1wpuDcgiBjleCLSBwg1J4NPn5JdzI'

# 用于保存对话历史的列表
dialogue_history = []

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.form['user_message']
    
    # 将用户消息添加到对话历史中
    dialogue_history.append({'role': 'user', 'content': user_message})
    
    # 使用OpenAI的ChatGPT API进行对话
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant which would provide suggestions to me if I give you topics, products or something to seek your help. You suggestions should be based on the empathy theory which could heal people emotionally. However, if I talk to you in a normal style, with no will to seek your help, you should talk to me normally as well."},
            # 将整个对话历史发送给ChatGPT
            *dialogue_history
        ]
    )
    
    # 获取ChatGPT的回复
    bot_reply = response.choices[0].message['content']
    
    # 将ChatGPT的回复添加到对话历史中
    dialogue_history.append({'role': 'assistant', 'content': bot_reply})
    
    return jsonify({'bot_reply': bot_reply})


if __name__ == '__main__':
    app.run(debug=True)
